Given /^I start the app the first time$/ do
    #Touch on next of the first screen
    touch("android.support.v7.widget.AppCompatButton id:'btn_save'")
    #Touch on next of the second screen
    touch("android.support.v7.widget.AppCompatButton id:'btn_save'")
    touch("android.support.v7.widget.AppCompatButton id:'btn_save'")
    sleep 1        
    touch("android.support.v7.widget.AppCompatCheckedTextView text:'Disable crash reports'")
    touch("android.support.v7.widget.AppCompatButton id:'btn_save'")
    touch("android.support.v7.widget.AppCompatButton id:'btn_save'")
    sleep 1
    touch("android.support.v7.widget.AppCompatButton id:'button1'")
end

Given /^I start the app and press next$/ do
    touch("android.support.v7.widget.AppCompatButton id:'btn_save'")
end

And /^I choose a random currency$/ do
    touch(query("android.support.v7.widget.AppCompatCheckedTextView")[rand(4)])
end

And /^I enable the crash report sending$/ do
    touch("android.support.v7.widget.AppCompatCheckedTextView text:'Automatically send crash reports'")
end

And /^I disable the crash report sending$/ do
    touch("android.support.v7.widget.AppCompatCheckedTextView text:'Automatically send crash reports'")
end

And /^I close the new in this version pop up$/ do
    touch("android.support.v7.widget.AppCompatButton id:'button1'")    
end

Then /^I press create transaction$/ do
    touch("android.support.design.widget.FloatingActionButton id:'fab_create_transaction'")
end

Then /^I enter my account name$/ do    
    touch("android.support.design.widget.TextInputLayout id:'name_text_input_layout'")         
    enter_text("android.support.design.widget.TextInputLayout id:'name_text_input_layout'", "Account test")
end

And /^I wait (\d+) seconds$/ do |value|
    sleep value
end

And /^I wait 1 second$/ do
    sleep 1
end